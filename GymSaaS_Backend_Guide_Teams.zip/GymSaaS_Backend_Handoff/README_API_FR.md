# GymSaaS — Guide API Backend pour Web & Mobile

**Statut : fonctions métier présentes, validation de production incomplète.** Les signatures ci-dessous ont été vérifiées dans le projet Supabase le 23 octobre 2026. Les appels clients réels doivent rester limités à un environnement de développement autorisé tant que RLS et l'isolation entre gyms ne sont pas validées.

## Projet et configuration
- Supabase Project ID : `axryzukwblmqjjounlhq`
- URL : `https://axryzukwblmqjjounlhq.supabase.co`
- Client Web Vite : `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`
- React Native / Expo : `EXPO_PUBLIC_SUPABASE_URL`, `EXPO_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
- **Interdit côté client :** `service_role` ou toute clé secrète.

```ts
import { createClient } from '@supabase/supabase-js';

export const supabase = createClient(
  import.meta.env.VITE_SUPABASE_URL,
  import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
);
```

## RPC de gestion
Les fonctions de mutation renvoient généralement un UUID (sauf indication contraire). Supabase reçoit automatiquement le JWT de la session via `supabase-js`.

| Fonction | Paramètres | Résultat / règle |
|---|---|---|
| `create_member` | `p_gym_id`, `p_member_number`, `p_full_name`, `p_phone?`, `p_profile_id?`, `p_photo_path?` | UUID ; vérifie `manage_members` |
| `update_member_status` | `p_member_id`, `p_status` | void ; statut `active`, `inactive` ou `blocked` |
| `create_membership_plan` | `p_gym_id`, `p_name`, `p_price`, `p_duration_days` | UUID ; propriétaire uniquement |
| `set_membership_plan_status` | `p_plan_id`, `p_is_active` | void ; propriétaire uniquement |
| `create_subscription` | `p_member_id`, `p_plan_id`, `p_start_date?` | UUID ; crée un abonnement `pending`, fin incluse calculée sur `duration_days - 1` |
| `renew_subscription` | `p_member_id`, `p_plan_id`, `p_start_date?` | UUID ; crée un nouvel enregistrement d'abonnement |
| `create_branch` | `p_gym_id`, `p_name` | UUID ; propriétaire uniquement |
| `set_branch_status` | `p_branch_id`, `p_status` | void ; `active` ou `inactive`, propriétaire uniquement |
| `add_gym_staff` | `p_gym_id`, `p_profile_id`, `p_role`, `p_permissions?` | UUID ; profil déjà inscrit requis ; rôle `gym_owner` ou `receptionist` |
| `set_gym_staff_permissions` | `p_staff_id`, `p_permissions` | void ; propriétaire uniquement, hors propriétaire cible |
| `record_payment` | `p_member_id`, `p_subscription_id?`, `p_amount`, `p_method`, `p_reference?` | UUID ; vérifie `record_payments`, active un abonnement `pending` si fourni |
| `cancel_payment` | `p_payment_id`, `p_reason` | void ; permission `cancel_payments`, motif obligatoire, audit log |
| `manual_checkin` | `p_member_id`, `p_branch_id` | UUID de visite ; personnel du gym, branche et abonnement actifs requis |
| `issue_qr_token` | `p_gym_id` | JSON `{ nonce, expires_at }` ; membre actif du gym, expiration après 30 s |
| `verify_qr` | `p_nonce`, `p_branch_id` | JSON ; `ok` et, en cas d'échec, `reason`; crée une visite si valide |
| `mark_notification_read` | `p_notification_id` | void ; notification du compte connecté uniquement |
| `manage_advertisement` | `p_title`, `p_content`, `p_start_date`, `p_end_date`, `p_status`, `p_gym_ids?`, `p_advertisement_id?` | UUID ; super-admin uniquement |
| `manage_platform_subscription` | `p_gym_id`, `p_amount`, `p_start_date`, `p_end_date`, `p_status`, `p_subscription_id?` | UUID ; super-admin uniquement |
| `set_gym_status` | `p_gym_id`, `p_status` | void ; super-admin, statut `active` ou `suspended` |

## RPC de lecture

| Fonction | Paramètres principaux | Résultat |
|---|---|---|
| `list_gym_members` | `p_gym_id`, `p_search?`, `p_status?`, `p_limit?`, `p_offset?` | JSON des membres, recherche et pagination (limite max 200) |
| `list_gym_plans` | `p_gym_id`, `p_include_inactive?` | JSON des forfaits |
| `list_gym_branches` | `p_gym_id`, `p_include_inactive?` | JSON des agences |
| `list_gym_subscriptions` | `p_gym_id`, `p_status?`, `p_member_id?`, `p_limit?`, `p_offset?` | JSON des abonnements |
| `list_gym_payments` | `p_gym_id`, `p_status?`, `p_member_id?`, `p_limit?`, `p_offset?` | JSON des paiements ; permission `view_payments` ou propriétaire |
| `list_gym_visits` | `p_gym_id`, `p_branch_id?`, `p_member_id?`, `p_from?`, `p_to?`, `p_limit?`, `p_offset?` | JSON des visites |
| `list_my_notifications` | `p_limit?`, `p_unread_only?` | Notifications du compte connecté |
| `get_gym_dashboard_stats` | `p_gym_id` | JSON de statistiques du gym ; membre du personnel requis |
| `get_platform_dashboard_stats` | aucun | JSON des statistiques plateforme ; super-admin uniquement |
| `list_active_advertisements` | aucun | JSON des annonces actives dans leur période ; public selon ACL actuelle |
| `expire_subscriptions` | aucun | entier : nombre d'abonnements expirés ; réservé à `service_role` |

Les paramètres optionnels doivent être envoyés avec les noms `p_...` exacts. Pour les paramètres non fournis, PostgreSQL applique les valeurs par défaut déclarées dans la signature.

## Exemple d'appel

```ts
const { data, error } = await supabase.rpc('list_gym_members', {
  p_gym_id: gymId,
  p_search: searchText || null,
  p_status: null,
  p_limit: 50,
  p_offset: 0,
});
if (error) throw error;
```

## Gestion des réponses QR

```ts
const { data, error } = await supabase.rpc('verify_qr', {
  p_nonce: nonce,
  p_branch_id: branchId,
});
if (error) throw error;
if (!data?.ok) {
  // Traiter data.reason sans afficher de détails SQL internes.
}
```

Raisons de refus prévues dans la fonction : `invalid_token`, `wrong_gym`, `invalid_branch`, `already_used`, `expired`, `member_inactive`, `subscription_inactive`.

## Règles d'intégration non négociables

- Toujours traiter `error`; ne jamais supposer qu'un appel a réussi.
- Ne pas écrire directement depuis le client dans `payments`, `qr_tokens`, `visits` ou `audit_logs`.
- Ne pas faire confiance à un `gym_id` provenant uniquement du formulaire.
- Les fonctions privilégiées ne dispensent pas de tester les rôles et l'isolation multi-gym.
- `notifications` stocke des messages ; aucun fournisseur d'envoi push/e-mail n'a été confirmé.
- La planification automatique de `expire_subscriptions()` n'est pas encore configurée.
- Consulter `04_SECURITY_REVIEW_FR.md` et `PRODUCTION_ACCEPTANCE_CHECKLIST.md` avant toute mise en production.
