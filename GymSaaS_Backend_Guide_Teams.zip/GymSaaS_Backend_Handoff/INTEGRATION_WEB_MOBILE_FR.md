# Intégration Web & Mobile — GymSaaS

## Authentification
Utiliser Supabase Auth. `supabase-js` joint automatiquement le JWT de session aux appels. Le profil applicatif est lié à `profiles.id = auth.users.id`.

## Fonctions disponibles
Le backend expose des RPC de gestion, de lecture et de tableaux de bord. La liste des signatures vérifiées, paramètres optionnels et exemples est dans `README_API_FR.md`. La revue de sécurité et les restrictions actuelles sont dans `04_SECURITY_REVIEW_FR.md`.

Domaines couverts : membres, forfaits, abonnements, agences, personnel, paiements, présences/QR, notifications, publicités, abonnements commerciaux des gyms et statistiques.

## Exemple client

```ts
const { data, error } = await supabase.rpc('create_subscription', {
  p_member_id: memberId,
  p_plan_id: planId,
  p_start_date: new Date().toISOString().slice(0, 10),
});
if (error) throw error;
```

## Limites et sécurité
- Le projet contient 15 tables avec RLS activé, mais aucune politique RLS n'a été définie. L'accès direct aux tables n'est donc pas validé pour les clients.
- Les RPC `SECURITY DEFINER` doivent être testées avec des JWT et rôles distincts ; voir la revue de sécurité.
- Ne jamais embarquer la clé `service_role` dans Web, Mobile ou le dépôt Git.
- Les permissions d'interface ne remplacent jamais l'autorisation côté base.
- `expire_subscriptions()` doit être appelée par une tâche planifiée sécurisée ; cette planification n'est pas configurée à ce jour.

**Décision :** les équipes peuvent commencer l'intégration UI et les appels en environnement de développement contrôlé. Le lancement public et l'utilisation de données réelles restent bloqués jusqu'à validation RLS, tests multi-gym et tests E2E.
