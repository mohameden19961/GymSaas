# Checklist d'acceptation avant production

- [ ] Politique SELECT/INSERT/UPDATE/DELETE explicitement définie pour chaque table et rôle.
- [ ] Aucun accès inter-salles possible pour un utilisateur authentifié.
- [ ] `anon` ne peut pas accéder aux tables métier.
- [ ] Les privilèges `MAINTAIN` et privilèges par défaut sont réduits au minimum nécessaire.
- [ ] Les RPC `SECURITY DEFINER` ont un `search_path` sûr et valident rôle, salle, statut suspendu et appartenance.
- [ ] `record_payment` refuse les montants non finis/invalides, est idempotent selon une clé métier et respecte le prix attendu.
- [ ] Annulation/remboursement: règles documentées et abonnement cohérent.
- [ ] QR à usage unique et expiré testé, y compris concurrence réelle.
- [ ] Création d'abonnement et de salle couverte par des RPC/politiques approuvées.
- [ ] Tests d'autorisation exécutés avec des JWT pour chaque rôle.
- [ ] Precheck sauvegardé et revu.
- [ ] Migration testée dans une branche/environnement séparé.
- [ ] Rollback testé et revu.
- [ ] Security Advisor post-déploiement vérifié.
- [ ] Types TypeScript régénérés après le dernier changement de schéma.
- [ ] Contrat API versionné et partagé avec les deux équipes.
