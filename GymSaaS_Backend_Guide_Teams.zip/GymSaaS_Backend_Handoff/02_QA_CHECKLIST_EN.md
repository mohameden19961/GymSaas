# GymSaaS Backend QA Checklist

## Test accounts
- [ ] Gym owner (Gym A)
- [ ] Receptionist with `manage_members=true`, `record_payments=true`, `renew_subscriptions=true`, `view_payments=false`, `cancel_payments=false`
- [ ] Receptionist in Gym B (cross-tenant isolation test)
- [ ] Regular member account linked to a member row
- [ ] Super-admin JWT with verified `app_metadata.role=super_admin`

## Members and plans
- [ ] Create member with valid fields.
- [ ] Duplicate member number in same gym is rejected.
- [ ] Search by name, member number, and phone; pagination works.
- [ ] Invalid member status is rejected.
- [ ] Receptionist without member permission cannot create/change members.
- [ ] Create plan with valid price/duration; invalid price/duration rejected.
- [ ] Receptionist cannot create or deactivate plans.

## Subscription lifecycle
- [ ] Create subscription for member and active plan in same gym.
- [ ] Cross-gym plan/member mismatch rejected.
- [ ] Payment on pending subscription activates it.
- [ ] Renewal creates a new row and does not overwrite history.
- [ ] Confirm inclusive end-date math and renewal start date with product.
- [ ] `expire_subscriptions` expires only active rows with end_date before current_date.

## Payments
- [ ] Record payment with each supported method.
- [ ] Invalid method and non-positive amount rejected by schema.
- [ ] Receptionist without `record_payments` is rejected.
- [ ] Payment list denied when no `view_payments` permission.
- [ ] Cancel payment requires reason and allowed permission.
- [ ] Confirm partial-payment/refund accounting expectations.

## QR and attendance
- [ ] QR nonce expires after 30 seconds.
- [ ] Token can only be used once; concurrent duplicate scan produces one visit.
- [ ] Wrong gym, inactive branch, inactive member, and expired subscription fail.
- [ ] Manual check-in rejects inactive branch/member and missing active subscription.
- [ ] Confirm whether multiple visits per member per day are allowed.

## Branches, staff, platform, ads
- [ ] Only gym owner can manage branches/staff/plans.
- [ ] Staff target profile must already exist.
- [ ] Permissions JSON is object and defaults are least-privilege.
- [ ] Cross-gym IDs are rejected or return no data.
- [ ] Non-super-admin cannot access platform dashboard or manage platform subscriptions/ads/gym status.
- [ ] Public ads only include active ads inside date range.
- [ ] User can read/mark only their own notifications.

## Release checks
- [ ] Verify function execute grants for `anon`, `authenticated`, and `service_role`.
- [ ] Verify RLS policy strategy before public launch; this work was deferred intentionally.
- [ ] Configure and monitor expiry scheduler.
- [ ] Confirm no service-role secret is bundled into frontend/mobile builds.
- [ ] Run full integration suite on staging before production release.
