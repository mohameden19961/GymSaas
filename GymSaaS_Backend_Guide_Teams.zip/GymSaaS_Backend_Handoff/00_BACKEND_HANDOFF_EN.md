# GymSaaS Backend Handoff

**Audience:** Web frontend, mobile frontend, QA, and product teams.  
**Backend:** Supabase (PostgreSQL + Supabase Auth + PostgREST RPC).  
**Project ref:** `axryzukwblmqjjounlhq`  
**Project URL:** `https://axryzukwblmqjjounlhq.supabase.co`  
**Status:** Core schema and three feature migrations are present in the connected project. Business-flow tests with real authenticated accounts have NOT been run.

## Important scope note
The user explicitly asked to defer RLS changes. No RLS policies were added or changed in these feature migrations. Since tables have RLS enabled and currently no policies, frontend teams must use the listed RPC functions rather than assume direct table `select/insert/update` calls will work. This handoff is not a security sign-off or public-launch approval.

## Supabase client convention
Use the official Supabase client and call functions through `supabase.rpc`:

```ts
const { data, error } = await supabase.rpc('list_gym_members', {
  p_gym_id: gymId,
  p_search: searchText || null,
  p_status: status || null,
  p_limit: 50,
  p_offset: 0,
});
if (error) throw error;
```

Never put the `service_role` key in a browser or mobile app. Client calls require a signed-in user unless a function is explicitly public. Platform-admin functions also require `app_metadata.role = "super_admin"` in the verified JWT. Do not allow clients to set this claim themselves.

## Migration ledger observed
- `20261022180720_initial_schema`
- `20261023080524_complete_core_business_functions`
- `20261023081332_complete_management_and_dashboard_api`
- `20261023081352_complete_read_api_and_platform_management`

## API catalogue
All parameters are named exactly as listed; pass UUIDs as strings and dates as `YYYY-MM-DD`.

### Members
- `create_member(p_gym_id uuid, p_member_number text, p_full_name text, p_phone text=null, p_profile_id uuid=null, p_photo_path text=null) -> uuid`
- `list_gym_members(p_gym_id uuid, p_search text=null, p_status text=null, p_limit int=100, p_offset int=0) -> jsonb array`
- `update_member_status(p_member_id uuid, p_status text) -> void`

### Plans
- `create_membership_plan(p_gym_id uuid, p_name text, p_price numeric, p_duration_days int) -> uuid`
- `list_gym_plans(p_gym_id uuid, p_include_inactive boolean=false) -> jsonb array`
- `set_membership_plan_status(p_plan_id uuid, p_is_active boolean) -> void`

### Subscriptions
- `create_subscription(p_member_id uuid, p_plan_id uuid, p_start_date date=current_date) -> uuid`
- `renew_subscription(p_member_id uuid, p_plan_id uuid, p_start_date date=current_date) -> uuid`
- `list_gym_subscriptions(p_gym_id uuid, p_status text=null, p_member_id uuid=null, p_limit int=100, p_offset int=0) -> jsonb array`
- `expire_subscriptions() -> integer`; service-role only. Schedule it with Supabase Cron/pg_cron or an approved server-side scheduler; it does not run itself.

**Date convention:** end date is inclusive: `start_date + duration_days - 1`. Renewal creates a new subscription row; it does not rewrite the old row. Product should confirm whether renewals should start today or the day after the current subscription ends.

### Branches and staff
- `create_branch(p_gym_id uuid, p_name text) -> uuid`
- `list_gym_branches(p_gym_id uuid, p_include_inactive boolean=false) -> jsonb array`
- `set_branch_status(p_branch_id uuid, p_status text) -> void`, status `active|inactive`
- `add_gym_staff(p_gym_id uuid, p_profile_id uuid, p_role text, p_permissions jsonb={}) -> uuid`, role `gym_owner|receptionist`; target profile must already exist.
- `set_gym_staff_permissions(p_staff_id uuid, p_permissions jsonb) -> void`

### Payments
Existing functions:
- `record_payment(p_member_id uuid, p_subscription_id uuid|null, p_amount numeric, p_method text, p_reference text|null) -> uuid`; methods `cash|bankily|masrvi|sedad`.
- `cancel_payment(p_payment_id uuid, p_reason text) -> void`; reason is required.
- `list_gym_payments(p_gym_id uuid, p_status text=null, p_member_id uuid=null, p_limit int=100, p_offset int=0) -> jsonb array`; requires `view_payments` or owner role.

### Attendance / QR
- `issue_qr_token(p_gym_id uuid) -> jsonb {nonce, expires_at}`; token lifetime is 30 seconds.
- `verify_qr(p_nonce text, p_branch_id uuid) -> jsonb`; inspect `ok` and `reason`; success includes `visit_id`.
- `manual_checkin(p_member_id uuid, p_branch_id uuid) -> uuid`
- `list_gym_visits(p_gym_id uuid, p_branch_id uuid=null, p_member_id uuid=null, p_from timestamptz=null, p_to timestamptz=null, p_limit int=100, p_offset int=0) -> jsonb array`

### Gym dashboard and notifications
- `get_gym_dashboard_stats(p_gym_id uuid) -> jsonb`: `members_total`, `members_active`, `subscriptions_active`, `subscriptions_expired`, `visits_today`, `payments_today`, `payments_total_recorded`, `branches_active`.
- `list_my_notifications(p_limit int=50, p_unread_only boolean=false) -> jsonb array`
- `mark_notification_read(p_notification_id uuid) -> void`

### Platform admin and advertisements
- `get_platform_dashboard_stats() -> jsonb`; requires super-admin JWT claim.
- `set_gym_status(p_gym_id uuid, p_status text) -> void`; requires super-admin claim; status `active|suspended`.
- `manage_platform_subscription(p_gym_id uuid, p_amount numeric, p_start_date date, p_end_date date, p_status text, p_subscription_id uuid=null) -> uuid`; super-admin only.
- `manage_advertisement(p_title text, p_content text, p_start_date date, p_end_date date, p_status text, p_gym_ids uuid[]= '{}', p_advertisement_id uuid=null) -> uuid`; super-admin only. Status `draft|active|paused|ended`.
- `list_active_advertisements() -> jsonb array`; public read function for active date-valid ads.

## Authorization assumptions
- Gym owner or staff membership is checked inside most gym RPCs.
- Owner-only actions include plan, branch and staff management.
- Payment listing checks `view_payments` (owners bypass the permission flag).
- Platform-wide actions check `auth.jwt().app_metadata.role = 'super_admin'`.
- `manual_checkin` currently requires gym staff membership but does not check a dedicated check-in permission because the current permissions schema has no such flag. Product/security should decide whether to add one.
- Do not expose `service_role` to clients. Do not assume definer functions replace RLS for direct table access.

## Known limitations / follow-up before production
1. RLS policies remain intentionally untouched. Tables are RLS-enabled; direct table access may return no rows or reject writes. Use RPCs until an approved RLS design is implemented.
2. Real authenticated workflow tests have not yet been run. Run the QA checklist with a gym owner, receptionist with limited permissions, regular member, and super-admin account.
3. `expire_subscriptions()` needs scheduling and monitoring.
4. Confirm renewal start-date policy and whether partial payments are allowed. `record_payment` currently does not enforce amount = plan price, intentionally leaving partial-payment rules to product.
5. `verify_qr` and `manual_checkin` need duplicate/day-level attendance policy confirmation.
6. `add_gym_staff` expects an existing `profiles` row, normally created after sign-up.
7. Audit and permissions should be reviewed before public launch. The user asked to defer RLS, so no RLS change is included.

## Release gate
Do not mark backend as production-ready until: RPC permissions verified; authenticated QA passes; QR duplicate/expiry tests pass; renewal and payment business rules are approved; expiry scheduling is configured; RLS and data isolation are reviewed and approved.
