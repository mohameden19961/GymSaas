# Deployment Notes

The connected Supabase project reports these migrations:

1. `initial_schema`
2. `complete_core_business_functions`
3. `complete_management_and_dashboard_api`
4. `complete_read_api_and_platform_management`

Migrations were applied using the Supabase migration tool. Read-only checks confirmed all four ledger entries. This does not mean business workflows were integration-tested.

## Important
- Do not rerun SQL manually as a second migration without checking the migration ledger.
- Do not run the RLS migrations from earlier review packages; RLS was explicitly deferred.
- Never commit `.env`, service-role keys, database passwords, or JWT secrets.
- Configure `expire_subscriptions()` using a trusted server-side scheduler; its execute permission is restricted to `service_role`.
- Use staging data/accounts to validate permissions and API response shapes before release.
