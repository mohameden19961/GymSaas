# Revue de sécurité Backend — GymSaaS

**Décision actuelle : intégration en développement possible avec prudence ; mise en production publique NON AUTORISÉE.** Cette revue est basée sur les définitions SQL et les Security Advisors du projet Supabase interrogés le 23 octobre 2026. Aucun test E2E avec JWT réels n'a été exécuté dans cette revue.

## Résultats confirmés

- Quatre migrations sont enregistrées : `initial_schema`, `complete_core_business_functions`, `complete_management_and_dashboard_api`, `complete_read_api_and_platform_management`.
- Le schéma expose 15 tables avec RLS activé, mais sans politiques RLS.
- Le Security Advisor signale 28 fonctions `SECURITY DEFINER` exécutables par `authenticated`, et `list_active_advertisements()` exécutable par `anon` et `authenticated`.
- Le code des fonctions métier vérifie généralement `auth.uid()` et/ou les rôles et permissions du gym. Cela ne remplace pas une vérification fonctionnelle par des JWT de différents rôles, ni la protection RLS des accès directs aux tables.
- Des clés étrangères sans index couvrant ont été signalées par l'advisor Performance. Il faut les examiner et ajouter des index adaptés après validation des requêtes et du schéma.

## Points à traiter avant la production

1. **RLS et isolation multi-gym** — définir et tester les politiques table par table. Vérifier qu'un membre du gym A ne peut ni lire ni modifier les données du gym B. Vérifier aussi les accès aux profils, journaux, paiements, QR et notifications.
2. **Fonctions privilégiées** — conserver `SECURITY DEFINER` uniquement lorsqu'il est nécessaire ; limiter explicitement `EXECUTE` aux rôles attendus ; vérifier chaque fonction avec des comptes non connectés, membres, réceptionnistes, propriétaires et super-admin.
3. **Paiements** — définir les règles métier de montants, méthodes, références, doublons/idempotence, annulation/remboursement et effet sur l'abonnement. La fonction actuelle n'établit pas que le montant payé correspond au prix du forfait.
4. **Check-in manuel** — confirmer si tout membre du personnel doit pouvoir enregistrer une présence ou si une permission dédiée est nécessaire.
5. **Gestion du personnel** — décider si un propriétaire peut attribuer le rôle `gym_owner` à d'autres utilisateurs ; la fonction actuelle l'autorise.
6. **Publicités** — l'accès anonyme à `list_active_advertisements()` semble prévu pour afficher des annonces publiques ; vérifier que seules les colonnes publiques sont retournées et documenter ce choix.
7. **Tâches planifiées** — planifier et surveiller `expire_subscriptions()` (actuellement accordée à `service_role`), puis tester les dates et fuseaux horaires.
8. **Tests d'intégration** — exécuter les scénarios positifs et négatifs avec deux gyms isolés et plusieurs rôles. Vérifier aussi les erreurs SQL, les courses concurrentes sur QR et la répétition des appels.
9. **Performance** — examiner les 11 clés étrangères sans index signalées par l'advisor. Les index inutilisés ne doivent pas être supprimés sur la seule base d'un rapport établi sur une base peu sollicitée.

## Contrôles manuels à effectuer

- [ ] Utilisateur anonyme : aucun accès aux données privées ; accès aux publicités actives uniquement si voulu.
- [ ] Réceptionniste : uniquement les actions correspondant à ses permissions.
- [ ] Propriétaire du gym A : aucune lecture ni mutation des données du gym B.
- [ ] Membre : ne peut créer que son propre QR et ne peut pas consulter les données d'autres membres.
- [ ] Super-admin : fonctions plateforme autorisées uniquement avec `app_metadata.role = super_admin` vérifié côté serveur.
- [ ] Paiement : montant invalide, méthode invalide, doublon et abonnement annulé refusés selon les règles décidées.
- [ ] QR : token expiré, déjà utilisé, mauvais gym et branche inactive refusés ; un seul scan concurrent accepté.
- [ ] Expiration : abonnement dont `end_date < current_date` expiré ; abonnement finissant aujourd'hui traité selon la règle métier documentée.

## Consignes de déploiement

- Ne jamais inclure la clé `service_role` ou une clé secrète dans Web, React Native, le dépôt Git ou les fichiers de configuration publics.
- Ne pas considérer le masquage d'un bouton comme une autorisation.
- Ne pas utiliser les écritures directes sur les tables sensibles depuis les clients avant la définition et la validation des politiques RLS.
- Ne pas annoncer « testé » ou « sécurisé » tant que les tests correspondants n'ont pas été exécutés et consignés.
