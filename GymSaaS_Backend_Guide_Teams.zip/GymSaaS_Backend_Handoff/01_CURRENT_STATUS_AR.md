# État actuel du Backend — GymSaaS

Le journal Supabase a été vérifié : trois migrations ont été ajoutées après le schéma initial. Des fonctions de gestion et de lecture ont été ajoutées, mais aucun test end-to-end avec des comptes réels n'a encore été réalisé.

## Périmètre des modifications

- **Membres :** création, liste avec recherche et pagination, modification du statut.
- **Forfaits :** création, liste, activation et désactivation.
- **Abonnements :** création et renouvellement sous forme de nouveaux enregistrements, liste et fonction de mise à jour des abonnements expirés.
- **Agences :** création, liste, activation et désactivation.
- **Personnel :** ajout d'un utilisateur déjà présent dans `profiles` et mise à jour de ses autorisations.
- **Paiements :** liste avec vérification du droit de consultation, en complément des fonctions existantes d'enregistrement et d'annulation.
- **Présences :** liste des visites, pointage manuel et fonctions QR déjà présentes.
- **Tableaux de bord :** statistiques de l'agence et de la plateforme, gestion du statut d'une agence, des abonnements de plateforme et des publicités.
- **Notifications :** liste des notifications de l'utilisateur et marquage d'une notification comme lue.

## Éléments non réalisés

- Les politiques RLS n'ont pas été modifiées, conformément à la demande.
- Aucune donnée de test n'a été ajoutée à la base de production.
- Tous les parcours n'ont pas été testés avec des comptes réels.
- La planification Cron pour exécuter `expire_subscriptions` n'a pas été configurée.

## Avertissement

Ce document constitue un guide d'intégration destiné aux équipes ; il ne représente pas une validation finale de la sécurité. Les tables de la base restent protégées par RLS, mais aucune politique RLS n'est actuellement définie. Il faut donc utiliser les RPC documentées et ne jamais intégrer la clé `service_role` dans l'application Web ou mobile. Le lancement public est déconseillé tant que les autorisations et l'isolation des données entre agences n'ont pas été testées et validées.
